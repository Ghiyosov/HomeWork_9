
### Task 1
### Create a solution of SoftclubApp.sln with same as shown in diagram.


![Screenshot_1](./Images/Screenshot_1.jpg)

![Screenshot_2](./Images/Screenshot_2.jpg)

![Screenshot_3](./Images/Screenshot_3.jpg)

![Screenshot_4](./Images/Screenshot_4.jpg)

